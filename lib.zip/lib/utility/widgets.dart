import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';

import '../screens/login_screen.dart';
import '../screens/sign_up_screen.dart';

// Welcome Screen log in button widget
Widget loginButton(double w, double h, BuildContext context) {
  return InkWell(
    onTap: () {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => LoginScreen()));
    },
    child: Container(
      width: w,
      padding: EdgeInsets.symmetric(vertical: h * 0.02),
      alignment: Alignment.center,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(h * 0.01)),
          boxShadow: <BoxShadow>[
            BoxShadow(
                color: Color(0xffdf8e33).withAlpha(100),
                offset: Offset(2, 4),
                blurRadius: 8,
                spreadRadius: 2)
          ],
          color: Colors.white),
      child: Text(
        'Login',
        style: TextStyle(fontSize: h * 0.03, color: Colors.purple),
      ),
    ),
  );
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Welcome Screen sign up button widget

Widget signUpButton(double w, double h, BuildContext context) {
  return InkWell(
    onTap: () {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => SignUpScreen()));
    },
    child: Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.symmetric(vertical: h * 0.02),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(h * 0.01)),
        border: Border.all(color: Colors.white, width: w * 0.01),
      ),
      child: Text(
        'Register now',
        style: TextStyle(fontSize: h * 0.03, color: Colors.white),
      ),
    ),
  );
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Welcome Screen title widget
Widget title(double w, double h, Color firstColor, Color secondColor) {
  return RichText(
    textAlign: TextAlign.center,
    text: TextSpan(
        text: 'S',
        style:
            // GoogleFonts.portLligatSans(
            TextStyle(
          fontSize: h * 0.05,
          fontWeight: FontWeight.w700,
          color: secondColor,
        ),
        children: [
          TextSpan(
            text: 'tore',
            style: TextStyle(color: firstColor, fontSize: h * 0.05),
          ),
          TextSpan(
            text: 'name',
            style: TextStyle(color: secondColor, fontSize: h * 0.05),
          ),
        ]),
  );
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// SignUp Screen back button widget

Widget backButton(double w, double h, BuildContext context) {
  return InkWell(
    onTap: () {
      Navigator.pop(context);
    },
    child: Container(
      padding: EdgeInsets.symmetric(horizontal: h * 0.02),
      child: Row(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(left: 0, top: h * 0.01, bottom: h * 0.01),
            child: Icon(Icons.keyboard_arrow_left, color: Colors.white),
          ),
          Text('Back',
              style: TextStyle(
                  fontSize: h * 0.02,
                  fontWeight: FontWeight.w500,
                  color: Colors.white))
        ],
      ),
    ),
  );
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Login Screen don't have account widget

Widget registerWidget(double w, double h, BuildContext context) {
  return InkWell(
    onTap: () {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => SignUpScreen()));
    },
    child: Container(
      margin: EdgeInsets.symmetric(vertical: h * 0.02),
      padding: EdgeInsets.all(w * 0.03),
      alignment: Alignment.bottomCenter,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            'Don\'t have an account ?',
            style: TextStyle(fontSize: h * 0.023, fontWeight: FontWeight.w600),
          ),
          SizedBox(
            width: w * 0.02,
          ),
          Text(
            'Register',
            style: TextStyle(
                color: Colors.purple,
                fontSize: h * 0.022,
                fontWeight: FontWeight.w600),
          ),
        ],
      ),
    ),
  );
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Login Screen don't have account widget

Widget loginWidget(double w, double h, BuildContext context) {
  return InkWell(
    onTap: () {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => LoginScreen()));
    },
    child: Container(
      margin: EdgeInsets.symmetric(vertical: h * 0.02),
      padding: EdgeInsets.all(w * 0.03),
      alignment: Alignment.bottomCenter,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            'Have an account ?',
            style: TextStyle(fontSize: h * 0.023, fontWeight: FontWeight.w600),
          ),
          SizedBox(
            width: w * 0.02,
          ),
          Text(
            'Login',
            style: TextStyle(
                color: Colors.purple,
                fontSize: h * 0.022,
                fontWeight: FontWeight.w600),
          ),
        ],
      ),
    ),
  );
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// SignUp Screen social account register widget

socialAccounts(
  double mWidth,
  double mHeight,
) {
  return Column(
    children: [
      Text(
        "Or ?",
        style: TextStyle(fontSize: mHeight * 0.025),
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: mWidth * 0.08,
            height: mHeight * 0.05,
            decoration: BoxDecoration(
                color: Colors.purple,
                borderRadius: BorderRadius.circular(mHeight * 0.5)),
            child: Icon(
              Ionicons.logo_google,
              color: Colors.white,
            ),
          ),
          SizedBox(
            width: mWidth * 0.1,
          ),
          Container(
            width: mWidth * 0.08,
            height: mHeight * 0.05,
            decoration: BoxDecoration(
                color: Colors.purple,
                borderRadius: BorderRadius.circular(mHeight * 0.5)),
            child: Icon(
              Ionicons.logo_twitter,
              color: Colors.white,
            ),
          ),
          SizedBox(
            width: mWidth * 0.1,
          ),
          Container(
            width: mWidth * 0.08,
            height: mHeight * 0.05,
            decoration: BoxDecoration(
                color: Colors.purple,
                borderRadius: BorderRadius.circular(mHeight * 0.5)),
            child: Icon(
              Icons.facebook_outlined,
              color: Colors.white,
            ),
          ),
        ],
      ),
      SizedBox(
        height: mHeight * 0.02,
      )
    ],
  );
}
